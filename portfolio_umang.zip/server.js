
// Simple Express server to receive contact form POSTs and send email via nodemailer.
// Save this file as server.js, run: npm init -y && npm i express nodemailer cors body-parser
const express = require('express');
const nodemailer = require('nodemailer');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname)));

app.post('/api/contact', async (req, res) => {
  const { name, email, subject, message } = req.body;
  if(!name || !email || !message) return res.status(400).send('Missing fields');

  try{
    // Configure your SMTP credentials here (Gmail example with App Password)
    let transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: { user: 'your.email@gmail.com', pass: 'your_app_password' }
    });

    await transporter.sendMail({
      from: 'your.email@gmail.com',
      to: 'umangagarwal427@gmail.com',
      subject: `[Portfolio Contact] ${subject}`,
      text: `From: ${name} <${email}>\n\n${message}`
    });
    res.sendStatus(200);
  }catch(err){
    console.error(err);
    res.status(500).send('Mail error');
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=>console.log('Server started on',PORT));
