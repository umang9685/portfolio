
Umang Agarwal — Portfolio Package
===============================

Files included:
- index.html
- Umang_Agarwal_photo.png  (your profile photo)
- Umang Agarwal Resume.pdf  (your resume)
- server.js                 (optional Node.js backend for contact form)
- README.md

How to preview locally:
1. Open `index.html` in a browser. (For full functionality like fetch to /api/contact you'll need a server.)
2. To use the Node.js backend: place all files in a project folder and run:
   - npm init -y
   - npm i express nodemailer cors body-parser
   - edit server.js with your email SMTP credentials
   - node server.js
   Then open http://localhost:3000

Using Formspree (no backend):
1. Create a free form at https://formspree.io
2. Copy your Formspree endpoint (it looks like https://formspree.io/f/abcdxyz)
3. Replace the form ACTION in index.html with your endpoint. The form will submit directly to Formspree and forward messages to your email.

Deploy to GitHub Pages:
1. Create a new GitHub repository and push these files to the repository root.
2. In repository Settings -> Pages, set source to main branch / root and save.
3. Your site will be available at https://<your-username>.github.io/<repo-name> within minutes.

Deploy to Netlify:
1. Sign in to Netlify and click 'Add new site' -> 'Deploy manually'.
2. Drag & drop the contents of this folder (index.html + assets) into the Netlify upload area.
3. Netlify will provide a URL. To use the Node backend you'll need Netlify Functions or a separate hosting for server.js.

Customizations:
- Update social links in index.html to your exact profiles.
- Replace the Formspree placeholder with your ID or configure server.js with real SMTP credentials.
